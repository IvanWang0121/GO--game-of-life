package main

import (
	"flag"
	"fmt"
	"net"
	"net/rpc"
	"time"
)

type Params struct {
	Threads     int
	ImageWidth  int
	ImageHeight int
}
type Request struct {
	Thread int
	World  [][]int
}

type Response struct {
	NextStateMap [][]int
}
type Gol struct{}

var world [][]int
var workingThread = 0
var maxThread = 0
var newTurnLine = make(chan []int)
var workDone = make(chan bool)
var needNewWorker = make(chan int)

// 服务器接收到图片信息后开始计算。并把新的图片更新在客户端上
func (s *Gol) CalculateNextState(request Request, response *Response) (err error) {
	start := time.Now()
	//for _, n := range request.World {
	//	fmt.Println(n)
	//}
	//fmt.Println("============================")
	workingThread = request.Thread
	for a := 1; a <= request.Thread; a++ {
		go Worker(Params{request.Thread, len(request.World[0]), len(request.World)}, request.World, a, true)
	}
	nextStateMap := waitWorkerDone(Params{request.Thread, len(request.World[0]), len(request.World)}, request.World)
	slice := nextStateMap[1 : len(nextStateMap)-1]
	response.NextStateMap = slice
	fmt.Println(time.Since(start))
	return
}
func main() {
	pAddr := flag.String("port", "8031", "Port to listen on")
	flag.Parse()
	err := rpc.Register(&Gol{})
	if err != nil {
		return
	}
	listener, _ := net.Listen("tcp", ":"+*pAddr)
	defer listener.Close()
	rpc.Accept(listener)
}

// 判断每行状态(new for gol)
func cellNextStateLine(p Params, world [][]int, line int) []int {
	var cellState []int
	var env int
	var ha, hb, hc, wa, wb, wc int
	ha = (line + p.ImageHeight - 1) % p.ImageHeight
	hb = line
	hc = (line + p.ImageHeight + 1) % p.ImageHeight
	wa = p.ImageWidth - 1
	wb = 0
	wc = 1
	env = world[ha][wa]*256 + world[hb][wa]*128 + world[hc][wa]*64 + world[ha][wb]*32 + world[hb][wb]*16 + world[hc][wb]*8 + world[ha][wc]*4 + world[hb][wc]*2 + world[hc][wc]*1
	cellState = append(cellState, envToState(env))
	for i := 1; i < p.ImageWidth; i++ {
		env = ((env % 64) * 8) + world[ha][(i+p.ImageWidth+1)%p.ImageWidth]*4 + world[hb][(i+p.ImageWidth+1)%p.ImageWidth]*2 + world[hc][(i+p.ImageWidth+1)%p.ImageWidth]*1
		cellState = append(cellState, envToState(env))
	}
	return cellState
}

// 环境转死活(new for gol)
func envToState(env int) int {
	var aliveCellNum, mainCell int
	mainCell = 0
	//与门判断env和000010000（16）
	if (env & 16) > 0 {
		mainCell = 1
	}
	aliveCellNum = 0
	for env > 0 {
		aliveCellNum += env & 1
		env = env >> 1
	}
	if (aliveCellNum == 3) || (aliveCellNum-mainCell) == 3 {
		return 1
	} else {
		return 0
	}
}

// 工人
func Worker(p Params, world [][]int, row int, a bool) {
	//todo:运行“判断每行状态”
	//a用来确保生产的goroutine 能正常回收 ，绑定：当生成goroutine-》参数为真；当函数即将结束，如果参数为真，代表这是个goroutine函数，需要告知
	//主函数以便回收线程数
	for {
		//fmt.Println(row)
		var output = cellNextStateLine(p, world, row)
		var alivecell = 0
		//在数组后添加2位 第一位记录这行活着的个数 第二位记录这是第几行
		output = append(output, alivecell)
		newTurnLine <- append(output, row)
		row += p.Threads
		if row >= p.ImageHeight-1 {
			break
		}
		//fmt.Println("output done,next:", row)
	}
	if a {
		workDone <- true
	}
}

// 等待工人干完
func waitWorkerDone(p Params, world [][]int) [][]int {
	result := make([][]int, p.ImageHeight)
	for {
		select {
		case <-workDone:
			workingThread--
			if workingThread == 0 {
				return result
			}
		case row := <-needNewWorker:
			workingThread++
			go Worker(p, world, row, true)
		case tmp := <-newTurnLine:
			result[tmp[len(tmp)-1]] = tmp[:len(tmp)-2]
		}
	}
}
