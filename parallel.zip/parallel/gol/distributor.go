package gol

import (
	"fmt"
	"time"
	"uk.ac.bris.cs/gameoflife/util"
)

type distributorChannels struct {
	events     chan<- Event
	ioCommand  chan<- ioCommand
	ioIdle     <-chan bool
	ioFilename chan<- string
	ioOutput   chan<- uint8
	ioInput    <-chan uint8
	keypress   <-chan rune
}

var workingThread = 0              //正在工作的线程数量
var newTurnLine = make(chan []int) //每行在新回合的样子
var workDone = make(chan bool)     //判断有无线程完成工作
var needNewWorker = make(chan int) // 是否需要新的线程

// distributor divides the work between workers and interacts with other goroutines.
func distributor(p Params, c distributorChannels) {

	// TODO: Create a 2D slice to store the world.
	c.ioCommand <- ioInput
	fileName := fmt.Sprintf("%dx%d", p.ImageWidth, p.ImageHeight)
	c.ioFilename <- fileName
	//OLDER
	//var world [][]uint8
	//for i := 0; i < p.ImageHeight; i++ {
	//	var tmp []uint8
	//	for j := 0; j < p.ImageWidth; j++ {
	//		tmp = append(tmp, <-c.ioInput)
	//	}
	//	world = append(world, tmp)
	//}
	//// TODO: Execute all turns of the Game of Life.
	//turn := 0
	//for ; turn < p.Turns; turn++ {
	//	world = calculateNextState(p, world)
	//}
	//// TODO: Report the final state using FinalTurnCompleteEvent.
	//
	//var aliveCellList []util.Cell
	////aliveCellList := make([]util.Cell, 0)
	//for h, l := range world {
	//	for w, d := range l {
	//		if d == 255 {
	//			aliveCellList = append(aliveCellList, util.Cell{w, h})
	//		}
	//	}
	//}

	//NEW
	//生成2dworld
	var world [][]int
	for i := 0; i < p.ImageHeight; i++ {
		var tmp []int
		var input uint8
		for j := 0; j < p.ImageWidth; j++ {
			input = <-c.ioInput
			if input == 255 {
				tmp = append(tmp, 1)
				c.events <- CellFlipped{CompletedTurns: 0, Cell: util.Cell{j, i}}
			} else {
				tmp = append(tmp, 0)
			}
		}
		world = append(world, tmp)
	}
	turn := 0
	//单线程
	//var nworld [][]int
	//for ; turn < p.Turns; turn++ {
	//	for i := 0; i < p.ImageHeight; i++ {
	//		nworld = append(nworld, cellNextStateLine(p, world, i))
	//	}
	//	world = nworld
	//	nworld = [][]int{}
	//}
	//todo：重写多线程
	start := time.Now() //标记时间
	for ; turn < p.Turns; turn++ {
		shutdown := false
		var alivecell = 0
		workingThread = p.Threads
		for workingThread := 0; workingThread < p.Threads; workingThread++ {
			go Worker(p, world, workingThread, true, c, turn)
		}
		world, alivecell = waitWorkerDone(p, world, c, turn)
		c.events <- TurnComplete{CompletedTurns: turn}
		if time.Since(start) >= 2 { //如果完成当前回合，距离上一次汇报不低于2秒，重置计时器并汇报event
			c.events <- AliveCellsCount{CompletedTurns: turn + 1, CellsCount: alivecell}
			start = time.Now()
		}
		select { //sdl模块检测键盘按键发送不同事件
		case a := <-c.keypress:
			switch a {
			case 'p': //暂停
				c.events <- StateChange{turn, Paused}
				if <-c.keypress == 'p' {
					c.events <- StateChange{turn, Executing}
				}
			case 's': //保存
				c.ioCommand <- ioOutput
				fileName := fmt.Sprintf("%dx%dx%d", p.ImageHeight, p.ImageWidth, turn)
				c.ioFilename <- fileName
				for i := 0; i < p.ImageHeight; i++ {
					for j := 0; j < p.ImageWidth; j++ {
						if world[i][j] == 1 {
							c.ioOutput <- 255
						} else {
							c.ioOutput <- 0
						}
					}
				}
				c.events <- ImageOutputComplete{CompletedTurns: turn, Filename: fileName}
			case 'q': //保存并退出
				c.ioCommand <- ioOutput
				fileName := fmt.Sprintf("%dx%dx%d", p.ImageHeight, p.ImageWidth, turn)
				c.ioFilename <- fileName
				for i := 0; i < p.ImageHeight; i++ {
					for j := 0; j < p.ImageWidth; j++ {
						if world[i][j] == 1 {
							c.ioOutput <- 255
						} else {
							c.ioOutput <- 0
						}
					}
				}
				c.events <- ImageOutputComplete{CompletedTurns: turn, Filename: fileName}
				shutdown = true
			default:
				break
			}
		default: //channel会阻塞代码运行，但我们不想代码阻塞，所以接收不到键盘案件就跳过
			break
		}
		if shutdown {
			break
		}
	}
	//todo：所有回合结束时，导出所有存活细胞到gol模块以便验证
	var aliveCellList []util.Cell
	for h, l := range world {
		for w, d := range l {
			if d == 1 {
				aliveCellList = append(aliveCellList, util.Cell{w, h})
			}
		}
	}
	c.events <- FinalTurnComplete{CompletedTurns: turn, Alive: aliveCellList}
	//todo：当所有回合结束，导出图像到io模块并保存
	fileName = fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, p.Turns)
	c.ioCommand <- ioOutput
	c.ioFilename <- fileName
	for _, i := range world {
		for _, j := range i {
			if j == 1 {
				c.ioOutput <- 255
			} else {
				c.ioOutput <- 0
			}
		}
	}
	//Make sure that the Io has finished any output before exiting.
	c.ioCommand <- ioCheckIdle
	<-c.ioIdle

	c.events <- StateChange{turn, Quitting}

	// Close the channel to stop the SDL goroutine gracefully. Removing may cause deadlock.
	close(c.events)

}

func calculateNextState(p Params, world [][]byte) [][]byte {
	var changelist [][]int
	for x := 0; x < p.ImageHeight; x++ {
		for y := 0; y < p.ImageWidth; y++ {
			if shouldCellChange(x, y, world, p) {
				changelist = append(changelist, []int{x, y})
			}
		}
	}
	for i := 0; i < len(changelist); i++ {
		if world[changelist[i][0]][changelist[i][1]] == 0 {
			world[changelist[i][0]][changelist[i][1]] = 255
		} else {
			world[changelist[i][0]][changelist[i][1]] = 0
		}
	}

	return world
}

// 细胞附近存活数量(old for gol)
func cellNeighborAlive(p Params, world [][]byte, x int, y int) int {
	var count int
	var neighborH int
	var neighborW int
	var actualh int
	var actialw int
	for neighborH = x - 1; neighborH <= x+1; neighborH++ {
		for neighborW = y - 1; neighborW <= y+1; neighborW++ {
			actualh = neighborH
			actialw = neighborW
			if neighborW == -1 {
				actialw = p.ImageWidth - 1
			}
			if neighborH == -1 {
				actualh = p.ImageHeight - 1
			}
			if neighborW == p.ImageWidth {
				actialw = 0
			}
			if neighborH == p.ImageHeight {
				actualh = 0
			}
			if IsAlive(actualh, actialw, world) { // ceil is alive
				count++
			}
		}
	}
	if IsAlive(x, y, world) {
		count--
	}
	return count
}

// 细胞存活判断(old for gol)
func IsAlive(x int, y int, world [][]byte) bool {

	if world[x][y] == 255 {
		return true
	} else {
		return false
	}
}

// 判断这个坐标的细胞是否应该变化(old for gol)
func shouldCellChange(x int, y int, world [][]byte, p Params) bool {
	if IsAlive(x, y, world) {
		if cellNeighborAlive(p, world, x, y) < 2 || cellNeighborAlive(p, world, x, y) > 3 {
			return true
		} else {
			return false
		}
	} else {
		if cellNeighborAlive(p, world, x, y) == 3 {
			return true
		} else {
			return false
		}
	}
}

// 判断每行状态(new for gol)
func cellNextStateLine(p Params, world [][]int, line int) []int {
	var cellState []int
	var env int
	var ha, hb, hc, wa, wb, wc int
	ha = (line + p.ImageHeight - 1) % p.ImageHeight
	hb = line
	hc = (line + p.ImageHeight + 1) % p.ImageHeight
	wa = p.ImageWidth - 1
	wb = 0
	wc = 1
	env = world[ha][wa]*256 + world[hb][wa]*128 + world[hc][wa]*64 + world[ha][wb]*32 + world[hb][wb]*16 + world[hc][wb]*8 + world[ha][wc]*4 + world[hb][wc]*2 + world[hc][wc]*1
	cellState = append(cellState, envToState(env))
	for i := 1; i < p.ImageWidth; i++ {
		env = ((env % 64) * 8) + world[ha][(i+p.ImageWidth+1)%p.ImageWidth]*4 + world[hb][(i+p.ImageWidth+1)%p.ImageWidth]*2 + world[hc][(i+p.ImageWidth+1)%p.ImageWidth]*1
		cellState = append(cellState, envToState(env))
	}
	return cellState
}

// 环境转死活(new for gol)
func envToState(env int) int {
	var aliveCellNum, mainCell int
	mainCell = 0
	//与门判断env和000010000（16）
	if (env & 16) > 0 {
		mainCell = 1
	}
	aliveCellNum = 0
	for env > 0 {
		aliveCellNum += env & 1
		env = env >> 1
	}
	if (aliveCellNum == 3) || (aliveCellNum-mainCell) == 3 {
		return 1
	} else {
		return 0
	}
}

// 工人
func Worker(p Params, world [][]int, row int, a bool, c distributorChannels, turn int) {
	//todo:运行“判断每行状态”
	//a用来确保生产的goroutine 能正常回收 ，绑定：当生成goroutine-》参数为真；当函数即将结束，如果参数为真，代表这是个goroutine函数，需要告知
	//主函数以便回收线程数
	for {
		var output = cellNextStateLine(p, world, row)
		var alivecell = 0
		for i, state := range output {
			if state == 1 {
				alivecell++
				if world[row][i] == 0 {
					c.events <- CellFlipped{CompletedTurns: turn, Cell: util.Cell{X: i, Y: row}}
				}
			} else {
				if world[row][i] == 1 {
					c.events <- CellFlipped{CompletedTurns: turn, Cell: util.Cell{X: i, Y: row}}
				}
			}
		}
		//在数组后添加2位 第一位记录这行活着的个数 第二位记录这是第几行
		output = append(output, alivecell)
		newTurnLine <- append(output, row)

		row += p.Threads
		if row >= p.ImageHeight {
			break
		}
	}

	if a {
		workDone <- true
	}
}

// 等待工人干完
func waitWorkerDone(p Params, world [][]int, c distributorChannels, turn int) ([][]int, int) {
	result := make([][]int, p.ImageHeight)
	var alivecell = 0
	for {
		select {
		case <-workDone:
			workingThread--
			if workingThread == 0 {
				return result, alivecell
			}
		case row := <-needNewWorker:
			workingThread++
			go Worker(p, world, row, true, c, turn)
		case tmp := <-newTurnLine:
			alivecell = alivecell + tmp[len(tmp)-2]
			result[tmp[len(tmp)-1]] = tmp[:len(tmp)-2]
		}
	}
}
